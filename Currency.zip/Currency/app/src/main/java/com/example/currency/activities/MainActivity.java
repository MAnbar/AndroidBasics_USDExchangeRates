package com.example.currency.activities;

import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.currency.R;

import java.util.List;

import com.example.currency.adaptors.CurrencyRateAdaptor;
import com.example.currency.handlers.ApiHandler;
import com.example.currency.models.CurrencyRate;


public class MainActivity extends AppCompatActivity {

    private List<CurrencyRate> currencyRateList;
    private RecyclerView recyclerView;

    private void initializeData() {
        currencyRateList = ApiHandler.getRates();
    }

    private void initializeAdapter() {
        CurrencyRateAdaptor currencyRateAdaptor = new CurrencyRateAdaptor(currencyRateList);
        recyclerView.setAdapter(currencyRateAdaptor);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycler_view);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        StrictMode.ThreadPolicy oldTP = StrictMode.getThreadPolicy();
        //StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitNetwork().build();

        StrictMode.setThreadPolicy(policy);

        initializeData();

        StrictMode.setThreadPolicy(oldTP);

        initializeAdapter();
    }
}

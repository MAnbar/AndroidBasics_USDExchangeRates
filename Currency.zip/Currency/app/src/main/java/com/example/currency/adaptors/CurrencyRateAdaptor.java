package com.example.currency.adaptors;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.currency.R;

import java.util.List;

import com.example.currency.models.CurrencyRate;

public class CurrencyRateAdaptor extends  RecyclerView.Adapter<CurrencyRateAdaptor.RateViewHolder>{

    public  List<CurrencyRate> currencyRateList;

    public CurrencyRateAdaptor(List<CurrencyRate> currencyRateList){

        this.currencyRateList = currencyRateList;
    }

    @Override
    public RateViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.currency_item, viewGroup, false);
        RateViewHolder evh = new RateViewHolder(v);
        return evh;
    }
    @Override
    public void onBindViewHolder(RateViewHolder rateViewHolder, int i) {
        rateViewHolder.rateName.setText(currencyRateList.get(i).getRateName());
        rateViewHolder.rate.setText(currencyRateList.get(i).getRate());
    }

    @Override
    public int getItemCount() {
        return currencyRateList.size();
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    public static class RateViewHolder extends RecyclerView.ViewHolder {
        //CardView cv;
        TextView rateName;
        TextView rate;

        RateViewHolder(View itemView) {
            super(itemView);
            //cv = (CardView)itemView.findViewById(R.id.cv);
            rateName = (TextView)itemView.findViewById(R.id.entry_rateName);
            rate = (TextView)itemView.findViewById(R.id.entry_rate);
        }
    }
}
